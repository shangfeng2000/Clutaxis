
from environment import *
import environment
import matplotlib.pyplot as plt
import time

def run_maze():
    success_num = 0
    fail_num = 0
    result = []
    for episode in range(10):
        # initial observation
        run_time = 0
        env.reset()
        time_in_episode = 0
        while True:
            time_in_episode += 1
            # fresh env
            env.render()
            # RL choose action based on observation
            start_time = time.time()
            action = env.choose_action()
            run_time += time.time() - start_time
            done = env.step(action)
            # break while loop when end of this episode
            if done == 1:
                success_num += 1
                env.save_result(episode)
                break
            elif done == 2:
                # env.save_result(episode)
                fail_num += 1
                break

        print('episode', episode, 'TIE', time_in_episode, 'FN', fail_num, run_time)
        q_est = mean(env.pf.q)
        sx, sy = env.source_location
        vx, vy = env.robot_start_position
        result.append([episode + 1, time_in_episode, run_time, done, q_est, sx, sy, vx, vy])

        if episode % 10 == 0:
            np.savetxt('./data/q' + str(Q) + 'v' + str(V) + '.txt', result, fmt='%.03f')

    print('Game Over')
    np.savetxt('./data/q' + str(Q) + 'v' + str(V) + '.txt', result, fmt='%.03f')
    env.destroy()


if __name__ == "__main__":
    # maze game
    # alpha = float(sys.argv[1])
    Q = 1
    V = 1

    alpha = 0.05

    environment.q = Q
    environment.v = V
    environment.Eps = 0.3
    environment.MinPts = 15
    environment.alpha = alpha
    environment.particle_total_number = 3000

    env = Maze()
    env.after(100, run_maze)
    env.mainloop()
