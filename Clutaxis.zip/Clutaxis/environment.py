﻿import numpy as np
import time
import sys
from pylab import *
import tkinter as tk
from sklearn.cluster import DBSCAN
import scipy.stats as stats
import copy
import scipy.io as scio
import math

q = 0
v = 0
particle_total_number = 0
MinPts = 0
Eps = 0
alpha = 0


UNIT = 50  # pixels
x_min = 0
x_max = 10
y_min = 0
y_max = 10
q_min = 0
q_max = 4
step = 0.5  # robot step


def diff(vx, vy, sx, sy, qq):
    """
    gas particle diffusion function
    vx/vy is the robot location,sx/sy is the source location \
    """
    a = 1
    d = 1
    t = 250
    lam = sqrt((d * t) / (1 + (v ** 2) * t / (4 * d)))
    f = sqrt((vx - sx)**2 + (vy - sy)**2)
    s = exp(-(sx - vx)*v/(2*d))
    k = exp(-f / lam)
    r = a * qq / f
    r = r * k * s
    return r

def DisplayParticle(cv, x, y):
    points = []
    for i in range(len(x)):
        r = part(cv, i, x[i], y[i])
        points.append(r)
    cv.update()
    return points

def DeleteParticle(cv, points):
    if points is not None:
        for p in points:
            cv.delete(p.cid)

class part:
    def __init__(self, cv, idx, x, y):
        self.id = idx
        self.x = x * UNIT
        self.y = y * UNIT
        self.cv = cv
        self.color = 'green'
        self.size = 2
        self.cid = self.cv.create_oval(
            self.x - self.size, self.y - self.size,
            self.x + self.size, self.y + self.size, fill=self.color)


class ParticleFilter:
    """
    particle filter
    """
    def __init__(self):
        # initialize the particles
        self.number = particle_total_number
        self.x = np.random.uniform(x_min, x_max, self.number)
        self.y = np.random.uniform(y_min, y_max, self.number)
        self.q = np.random.uniform(q_min, q_max, self.number)
        self.weight = np.full(self.number, 1/self.number)

    def update(self, r_x, r_y, detection):
        lamd = diff(r_x, r_y, self.x, self.y, self.q)
        probablity = stats.poisson.pmf(detection, lamd)
        self.weight *= probablity
        self.weight /= sum(self.weight)


    def resample(self):
        new_particle_x = np.zeros(self.number)
        new_particle_y = np.zeros(self.number)
        new_particle_q = np.zeros(self.number)
        for i in range(self.number):
            cumsum_weight = np.cumsum(self.weight)
            rand_number = np.random.rand()
            target = next(n for n in cumsum_weight if n > rand_number)
            index = np.argwhere(cumsum_weight == target)

            new_particle_x[i] = self.x[index[0]]
            new_particle_y[i] = self.y[index[0]]
            new_particle_q[i] = self.q[index[0]]

        self.x = new_particle_x
        self.y = new_particle_y
        self.q = new_particle_q
        self.weight = np.full(self.number, 1 / self.number)

    def mcmcStep(self, r_x, r_y, detection):

        for i in range(self.number):
            x_candidate = np.random.normal(loc=self.x[i], scale=0.1)
            y_candidate = np.random.normal(loc=self.y[i], scale=0.1)
            q_candidate = np.random.normal(loc=self.q[i], scale=0.04)
            if (x_candidate < x_max) & (x_candidate > x_min) & \
               (y_candidate < y_max) & (y_candidate > y_min) & \
               (q_candidate < q_max) & (q_candidate > q_min):
                mean1 = diff(r_x, r_y, x_candidate, y_candidate, q_candidate)
                mean2 = diff(r_x, r_y, self.x[i], self.y[i], self.q[i])
                prob1 = stats.poisson.pmf(detection, mean1)
                prob2 = stats.poisson.pmf(detection, mean2)
                al = min(1, prob1 / prob2)
                if np.random.rand() <= al:
                    self.x[i] = x_candidate
                    self.y[i] = y_candidate
                    self.q[i] = q_candidate

    def reset(self):
        self.x = np.random.uniform(x_min, x_max, self.number)
        self.y = np.random.uniform(y_min, y_max, self.number)
        self.q = np.random.uniform(q_min, q_max, self.number)
        self.weight = np.full(self.number, 1 / self.number)

    def save(self):
        X = np.vstack((self.x, self.y)).T
        np.savetxt('data.txt', X)


class Maze(tk.Tk, object):
    def __init__(self):
        super(Maze, self).__init__()
        self.title('clutaxis_al' + str(alpha) + 'q' + str(q) + 'v' + str(v))
        self.geometry('{0}x{1}'.format(x_max * UNIT, y_max * UNIT))
        self.pf = ParticleFilter()
        self.canvas = tk.Canvas(self, height=y_max * UNIT, width=x_max * UNIT)
        # self.source_location = np.array([6, 6.67])
        # self.robot_start_position = np.array([0.67, 1.67])
        '''
        self.source_location = np.random.uniform(x_min, x_max, 2)
        self.robot_start_position = np.random.uniform(x_min, x_max, 2)
        self.robot_current_position = self.robot_start_position
        self.particle_all = []
        self.track = []
        self.mean_point = []
        self._build_maze()
        '''

    def _build_maze(self):

        # particles
        self.points = DisplayParticle(self.canvas, self.pf.x, self.pf.y)

        source = self.canvas.create_oval(UNIT * self.source_location[0] - 5,
                                         UNIT * self.source_location[1] - 5,
                                         UNIT * self.source_location[0] + 5,
                                         UNIT * self.source_location[1] + 5, fill='red')

        start_point = self.canvas.create_oval(UNIT * self.robot_start_position[0] - 5,
                                         UNIT * self.robot_start_position[1] - 5,
                                         UNIT * self.robot_start_position[0] + 5,
                                         UNIT * self.robot_start_position[1] + 5, fill='blue')

        self.canvas.pack()
        self.count = 0

    def reset(self):
        # self.update()
        # time.sleep(0.1)
        self.canvas.delete("all")
        self.update()
        self.pf.reset()
        self.source_location = np.array([6, 6.5])
        self.robot_start_position = np.array([0.5, 0.5])
        # self.source_location = np.random.uniform(x_min, x_max, 2)
        # self.robot_start_position = np.random.uniform(x_min, x_max, 2)
        #  self.source_location = location[0:2]
        # self.robot_start_position = location[2:4]
        self.robot_current_position = copy.copy(self.robot_start_position)
        self.particle_all = []
        self.track = []
        self.mean_point = []
        self.flag = 0
        self.flag_increment = 0
        self.flag_count = 0

        self._build_maze()
        # return observation ()
        r_x = self.robot_current_position[0]
        r_y = self.robot_current_position[1]
        self.position = self.canvas.create_oval(UNIT * r_x - 4, UNIT * r_y - 4, UNIT * r_x + 4, UNIT * r_y + 4,
                                                fill='blue')
        self.target = self.canvas.create_oval(UNIT * x_max / 2 - 4, UNIT * y_max / 2 - 4,
                                              UNIT * x_max / 2 + 4, UNIT * y_max / 2 + 4, fill='yellow')

        # self.pf.save()
        self.track.append([r_x, r_y, 0])
        xy = np.vstack((self.pf.x, self.pf.y)).T
        h = np.array([xy, xy])
        self.particle_all = h.tolist()
        self.mean_point.append([x_max/2, y_min/2])

        return

    def step(self, action):
        self.count += 1
        last_robot_position = copy.copy(self.robot_current_position)
        x_next = step * math.cos(action) + self.robot_current_position[0]
        y_next = step * math.sin(action) + self.robot_current_position[1]

        if (x_min < x_next < x_max) & (y_min < y_next < y_max):
            self.robot_current_position = [x_next, y_next]

        r_x = self.robot_current_position[0]
        r_y = self.robot_current_position[1]
        detection = np.random.poisson(diff(r_x, r_y, self.source_location[0],
                                           self.source_location[1], q))

        self.canvas.delete(self.position)
        self.position = self.canvas.create_oval(UNIT * r_x - 4, UNIT * r_y - 4,
                                                UNIT * r_x + 4, UNIT * r_y + 4, fill='blue')

        self.pf.update(r_x, r_y, detection)
        if detection > 0:
            self.canvas.create_oval(UNIT * r_x - 3, UNIT * r_y - 3, UNIT * r_x + 3, UNIT * r_y + 3, fill='red')
        else:
            self.canvas.create_oval(UNIT * r_x - 2, UNIT * r_y - 2, UNIT * r_x + 2, UNIT * r_y + 2, fill='yellow')

        self.canvas.create_line(UNIT * last_robot_position[0], UNIT * last_robot_position[1], UNIT * r_x, UNIT * r_y)

        neff = 1 / sum(np.square(self.pf.weight))
        if neff < 0.60 * self.pf.number:
            self.pf.resample()
            self.pf.mcmcStep(r_x, r_y, detection)
            DeleteParticle(self.canvas, self.points)
            self.points = DisplayParticle(self.canvas, self.pf.x, self.pf.y)
            self.flag = 0
            self.flag_increment = 0
            self.flag_count = 0
            # self.pf.save()

        xy = np.vstack((self.pf.x, self.pf.y)).T  # recond particle
        self.particle_all.append(xy.tolist())
        self.track.append([r_x, r_y, detection])

        distance = math.sqrt((r_x-self.source_location[0])**2 + (r_y-self.source_location[1])**2)
        if distance < 0.56:
            done = 1
        else:
            done = 0
        if self.count > 399:
            done = 2

        return done

    def choose_action(self):
        if self.flag == 0:
            r_x, r_y = self.robot_current_position
            action = self.samplefeature(r_x, r_y)
            # if np.random.uniform() > random_action:
                # action = np.random.uniform(-3.14, 3.14)

        elif self.flag == 1:
            action = math.pi/2
            self.flag_count += 1
            if self.flag_count > self.flag_increment:
                self.flag = 2
                self.flag_increment += 1
                self.flag_count = 0

        elif self.flag == 2:
            action = math.pi
            self.flag_count += 1
            if self.flag_count > self.flag_increment:
                self.flag = 3
                self.flag_increment += 1
                self.flag_count = 0

        elif self.flag == 3:
            action = -math.pi/2
            self.flag_count += 1
            if self.flag_count > self.flag_increment:
                self.flag = 4
                self.flag_increment += 1
                self.flag_count = 0

        elif self.flag == 4:
            action = 0
            self.flag_count += 1
            if self.flag_count > self.flag_increment:
                self.flag = 1
                self.flag_increment += 1
                self.flag_count = 0

        return action

    def samplefeature(self, r_x, r_y):
        X = np.vstack((self.pf.x, self.pf.y)).T
        y_pred = DBSCAN(eps=0.3, min_samples=15).fit_predict(X)
        y_pred += 1
        count = np.bincount(y_pred)
        '''
        feature1 = count[0] / self.pf.number 
        feature2 = np.delete(count, 0).max() / self.pf.number 
        if feature2 <= alpha:
            feature2 = 0
        '''
        valid_cluster = count[count > self.pf.number * alpha]

        feature3 = len(valid_cluster)  # number of valid cluster
        if count[0] > self.pf.number * alpha:
            feature3 -= 1

        # index = count.argmax()
        if feature3 > 0:  # choose the maximum valid cluster
            index = np.delete(count, 0).argmax() + 1
            num = np.delete(count, 0).max()
            x_sum = 0
            y_sum = 0
            for i in range(self.pf.number):
                if y_pred[i] == index:
                    x_sum += X[i, 0]
                    y_sum += X[i, 1]
            mean_x = x_sum / num
            mean_y = y_sum / num

        else:
            # index = count.argmax()  # choose the maximum cluster
            # num = count.max()
            mean_x = mean(X[:, 0])
            mean_y = mean(X[:, 1])

        self.mean_point.append([mean_x, mean_y])
        self.canvas.delete(self.target)
        self.target = self.canvas.create_oval(UNIT * mean_x - 4, UNIT * mean_y - 4,
                                              UNIT * mean_x + 4, UNIT * mean_y + 4, fill='yellow')
        feature4 = mean_x - r_x
        feature5 = mean_y - r_y
        feature6 = math.atan2(feature5, feature4)

        if (abs(feature4) < step) & (abs(feature5) < step):
            self.flag = 1

        Feature = feature6

        return Feature

    def save_result(self, episode):
        del self.particle_all[0]
        dataNew = './data/q'+str(q)+'v'+str(v)+'track'+str(episode)+'.mat'
        scio.savemat(dataNew, {'source_location': self.source_location,
                               'track': self.track,
                               'particle': self.particle_all,
                               'mean_point': self.mean_point,
                               'q': q, 'v': v, 'X': x_max, 'Y': y_max,
                               'particle_number': particle_total_number})

    def render(self):
        self.update()


if __name__ == "__main__":
    env = Maze()
    for i in range(200):
        env.render()
    env.mainloop()



